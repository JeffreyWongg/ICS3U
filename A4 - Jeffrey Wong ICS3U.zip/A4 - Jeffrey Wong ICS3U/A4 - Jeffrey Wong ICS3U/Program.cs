﻿//Jeffrey Wong
//ICS3U
//September 6th, 2023
//A4

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A4___Jeffrey_Wong_ICS3U
{
    class Program
    {
        static void Main(string[] args)
        {
            //12 times table
            Console.WriteLine("1 x 12 = " + (1 * 12)); //Prints 1 x 12 and then calculates
            Console.WriteLine("2 x 12 = " + (2 * 12)); //Prints 2 x 12 and then calculates
            Console.WriteLine("3 x 12 = " + (3 * 12)); //Prints 3 x 12 and then calculates
            Console.WriteLine("4 x 12 = " + (4 * 12)); //Prints 4 x 12 and then calculates
            Console.WriteLine("5 x 12 = " + (5 * 12)); //Prints 5 x 12 and then calculates
            Console.WriteLine("6 x 12 = " + (6 * 12)); //Prints 6 x 12 and then calculates
            Console.WriteLine("7 x 12 = " + (7 * 12)); //Prints 7 x 12 and then calculates
            Console.WriteLine("8 x 12 = " + (8 * 12)); //Prints 8 x 12 and then calculates
            Console.WriteLine("9 x 12 = " + (9 * 12)); //Prints 9 x 12 and then calculates
            Console.WriteLine("10 x 12 = " + (10 * 12)); //Prints 10 x 12 and then calculates
            Console.WriteLine("11 x 12 = " + (11 * 12)); //Prints 11 x 12 and then calculates
            Console.WriteLine("12 x 12 = " + (12 * 12)); //Prints 12 x 12 and then calculates

            Console.ReadKey();
        }
    }
}
